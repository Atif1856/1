const CATEGORIES = [
  ["🗑️","Garbage & Waste","Overflowing bins, illegal dumping, collection issues."],
  ["🛣️","Roads & Potholes","Potholes, broken roads, damaged sidewalks."],
  ["💧","Water","Supply, leakage, contamination or access issues."],
  ["🚰","Drainage / Sewerage","Blocked drains, sewage overflow and flooding."],
  ["💡","Street Lights","Broken, missing or unsafe street lighting."],
  ["🚦","Traffic","Signals, congestion and road-safety concerns."],
  ["🏗️","Infrastructure","Public buildings, bridges and other assets."],
  ["🌳","Public Spaces","Parks, footpaths and public-space maintenance."],
  ["🐾","Animal / Safety","Public safety or animal-related civic issues."],
  ["＋","Other","Anything that does not fit the categories above."]
];

const FAQS = [
  ["Is KARACHI FIX an official government website?","No. This GitHub version is a civic-tech prototype and is not an official government service."],
  ["Can I report a pothole?","Yes. Select Roads & Potholes, describe the issue, add the area and submit the report."],
  ["Can I upload evidence?","The frontend accepts an image/video file name in demo mode. A production backend should securely upload and store the actual file."],
  ["How does K-FIX AI work?","In the production architecture, AI can classify the complaint, summarize it, suggest priority and identify possible duplicates. Human review should remain available."],
  ["Will AI automatically make decisions?","It should not make high-impact civic decisions without appropriate human review and safeguards."],
  ["Can I track my complaint?","Yes. This prototype stores submitted reports in your browser and shows their status in the dashboard."],
  ["Can I reopen a resolved report?","The production workflow can allow citizen confirmation or reopening when the reported issue is not actually fixed."],
  ["How are organizations verified?","A production system can require registration documents, service-area information, review and approval before an organization receives cases."],
  ["Will my location be public?","A production system should clearly explain what location data is public, private or restricted and apply access controls."],
  ["Can organizations collaborate on a case?","Yes. The planned architecture supports case collaboration, comments, evidence and status updates."],
  ["Can emergencies be reported?","The production system should distinguish civic complaints from immediate emergencies and direct users to appropriate emergency channels."],
  ["Can I search complaints?","A production dashboard can provide search and filters by category, status, area, date and organization."],
  ["Can citizens rate a resolution?","The planned workflow can collect citizen confirmation and optional feedback after resolution."],
  ["Does this site send real notifications?","Not in this GitHub-only demo. Email/SMS/push notifications require backend services."],
  ["Where is the database?","This prototype uses browser localStorage. Production needs a secure server-side database."],
  ["Can I log in?","Authentication is not connected in this static prototype. A production version should use secure authentication and sessions."],
  ["Can NGOs join?","The product concept supports verified welfare and NGO accounts with defined capabilities and service areas."],
  ["Can government teams use it?","The planned role-based architecture includes government dashboards, assignments and case updates."],
  ["Can the map use real Karachi data?","Yes, after connecting a mapping provider and a backend dataset. This prototype uses a visual mock map."],
  ["What should never be stored in the browser?","Secrets, API keys, passwords and sensitive private documents should not be placed in frontend code or localStorage."]
];

const demoIssues = [
  {id:"KF-2026-0001024",title:"Large pothole on main road",category:"Roads & Potholes",location:"Gulshan-e-Iqbal",status:"In Progress",priority:"High"},
  {id:"KF-2026-0001018",title:"Blocked drainage line",category:"Drainage / Sewerage",location:"North Nazimabad",status:"Submitted",priority:"Critical"},
  {id:"KF-2026-0000997",title:"Street light not working",category:"Street Lights",location:"PECHS",status:"Resolved",priority:"Normal"}
];

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function toast(message){
  const el=$("#toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(window.__toast); window.__toast=setTimeout(()=>el.classList.remove("show"),3200);
}

function scrollToTarget(selector){
  const el=document.querySelector(selector); if(el) el.scrollIntoView({behavior:"smooth",block:"start"});
}

function getReports(){
  try{return JSON.parse(localStorage.getItem("karachiFixReports")||"[]")}catch{return []}
}
function saveReports(reports){localStorage.setItem("karachiFixReports",JSON.stringify(reports));}

function renderCategories(){
  $("#categoryGrid").innerHTML=CATEGORIES.map(([icon,name,desc])=>`
    <article class="category" data-category="${name}">
      <div class="icon">${icon}</div><h3>${name}</h3><p>${desc}</p>
    </article>`).join("");
  $("#category").innerHTML='<option value="">Select a category</option>'+CATEGORIES.map(x=>`<option>${x[1]}</option>`).join("");
  $("#mapFilter").innerHTML='<option value="all">All problems</option>'+CATEGORIES.map(x=>`<option>${x[1]}</option>`).join("");
}

function renderFaq(){
  $("#faqList").innerHTML=FAQS.map(([q,a])=>`<div class="faq"><button type="button">${q}<span>＋</span></button><p>${a}</p></div>`).join("");
  $$(".faq button").forEach(btn=>btn.addEventListener("click",()=>btn.parentElement.classList.toggle("open")));
}

function renderDashboard(){
  const reports=getReports();
  const all=[...demoIssues,...reports];
  const resolved=all.filter(x=>String(x.status).toLowerCase().includes("resolved")).length;
  const progress=all.filter(x=>String(x.status).toLowerCase().includes("progress")).length;
  $("#dashboardStats").innerHTML=[
    ["Total reports",all.length],["Submitted",all.filter(x=>x.status==="Submitted").length],
    ["In progress",progress],["Resolved",resolved]
  ].map(([a,b])=>`<div class="stat-card"><b>${b}</b><small>${a}</small></div>`).join("");

  $("#reportsList").innerHTML=all.slice().reverse().map(x=>{
    const cls=String(x.status).toLowerCase().includes("resolved")?"resolved":String(x.status).toLowerCase().includes("progress")?"progress":"";
    return `<div class="report-row"><div class="id">${x.id}</div><div><h4>${escapeHtml(x.title)}</h4><p>${escapeHtml(x.category)} · ${escapeHtml(x.location)} · ${escapeHtml(x.priority||"Normal")} priority</p></div><div class="status ${cls}">${escapeHtml(x.status)}</div></div>`;
  }).join("");
}

function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

function analyzeReport(){
  const category=$("#category").value||"Other";
  const urgency=$("#urgency").value;
  const title=$("#title").value.trim();
  const desc=$("#description").value.trim();
  let priority=urgency==="critical"?"Critical":urgency==="high"?"High":"Normal";
  if(/sewer|drain|fire|danger|accident|exposed|electric/i.test(`${title} ${desc}`)) priority="High";
  const summary=desc?desc.slice(0,170)+(desc.length>170?"…":""):"No description provided";
  $("#aiPreview").textContent=`Suggested category: ${category} · Priority: ${priority} · Confidence: demo`;
  $("#reportSummary").innerHTML=`<strong>AI suggestion</strong><br>Category: ${escapeHtml(category)}<br>Priority: ${priority}<br>Summary: ${escapeHtml(summary)}<br><br><span style="color:#6f8398">Demo only — production AI should run server-side and allow human review.</span>`;
}

let currentStep=1;
function showStep(step){
  currentStep=step;
  $$(".form-step").forEach(x=>x.classList.toggle("active",Number(x.dataset.step)===step));
  $$(".form-progress span").forEach((x,i)=>x.classList.toggle("active",i<step));
  if(step===3) analyzeReport();
}

function validateStep(step){
  const fields=step===1?[$("#category"),$("#title"),$("#description")]:[$("#location")];
  for(const field of fields){if(!field.value.trim()){field.reportValidity?.();field.focus();return false;}}
  return true;
}

function setup(){
  renderCategories();renderFaq();renderDashboard();

  $$("[data-scroll]").forEach(btn=>btn.addEventListener("click",()=>scrollToTarget(btn.dataset.scroll)));
  $("#menuBtn").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
  $$("#mainNav a").forEach(a=>a.addEventListener("click",()=>$("#mainNav").classList.remove("open")));

  $$(".next-step").forEach(btn=>btn.addEventListener("click",()=>{
    if(validateStep(currentStep)) showStep(Math.min(3,currentStep+1));
  }));
  $$(".prev-step").forEach(btn=>btn.addEventListener("click",()=>showStep(Math.max(1,currentStep-1))));

  $$(".category").forEach(card=>card.addEventListener("click",()=>{
    $("#category").value=card.dataset.category;scrollToTarget("#report");toast(`${card.dataset.category} selected`);
  }));

  $$(".pin").forEach(pin=>pin.addEventListener("click",()=>toast(pin.dataset.pin||"Civic issue marker")));
  $("#clearDemo").addEventListener("click",()=>{localStorage.removeItem("karachiFixReports");renderDashboard();toast("Your locally saved demo reports were cleared.");});

  $("#reportForm").addEventListener("submit",e=>{
    e.preventDefault();
    if(!validateStep(2)) return;
    const reports=getReports();
    const id=`KF-2026-${String(1025+reports.length).padStart(7,"0")}`;
    const urgency=$("#urgency").value;
    const report={
      id,title:$("#title").value.trim(),description:$("#description").value.trim(),
      category:$("#category").value,location:$("#location").value.trim(),
      priority:urgency==="critical"?"Critical":urgency==="high"?"High":"Normal",
      media:$("#media").files[0]?.name||"",status:"Submitted",createdAt:new Date().toISOString()
    };
    reports.push(report);saveReports(reports);renderDashboard();
    $("#reportForm").reset();showStep(1);scrollToTarget("#dashboard");
    toast(`Report submitted successfully. ID: ${id}`);
  });

  $("#roleBtn").addEventListener("click",()=>{
    const roles=["Citizen","Government","Welfare","Moderator"];
    const current=$("#roleBtn").textContent;const next=roles[(roles.indexOf(current)+1)%roles.length];
    $("#roleBtn").textContent=next;toast(`Demo role switched to ${next}`);
  });
}
document.addEventListener("DOMContentLoaded",setup);
